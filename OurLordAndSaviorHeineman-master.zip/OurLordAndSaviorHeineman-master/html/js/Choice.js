
function processCreateResponse(arg1, arg2,  result) {

	console.log("result:" + result);
	var js = JSON.parse(result);

	var computation = js;

	document.addForm.result.value = computation["choice"]["id"];
	
    window.location.href = "choice.html?cid=" + computation["choice"]["id"];
    
}

function handleChoiceClick(e) {
	var form = document.addForm;
	var arg1 = form.arg1.value;
	var arg2 = form.arg2.value;

	var alt1 = form.alt1.value;
	var alt2 = form.alt2.value;
	var alt3 = form.alt3.value;
	var alt4 = form.alt4.value;
	var alt5 = form.alt5.value;
	
	

   
 
	var data = {};
	data["description"] = arg1;
	data["memberCount"] = arg2;
	if(alt1.length > 0)
		data["altdescription1"] = alt1;
	if(alt2.length > 0)
		data["altdescription2"] = alt2;
	if(alt3.length > 0)
		data["altdescription3"] = alt3;
	if(alt4.length > 0)
		data["altdescription4"] = alt4;
	if(alt5.length > 0)
		data["altdescription5"] = alt5;






	var js = JSON.stringify(data);
	console.log("JS:" + js);
	var xhr = new XMLHttpRequest();
	xhr.open("POST", create_url, true);

	// send the collected data as JSON
	xhr.send(js);

	// This will process results and update HTML as appropriate. 
	xhr.onloadend = function() {
		console.log(xhr);
		console.log(xhr.request);

		if (xhr.readyState == XMLHttpRequest.DONE) {
			console.log("XHR:" + xhr.responseText);
			processCreateResponse(arg1, arg2, xhr.responseText);
		} else {
			processCreateResponse(arg1, arg2, "N/A");
		}
	};
}



