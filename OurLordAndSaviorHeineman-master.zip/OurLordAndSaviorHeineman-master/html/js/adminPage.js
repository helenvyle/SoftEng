function processGenerateResponse(result) {
    console.log("result:" + result);
    var js = JSON.parse(result);
    var computation = js;
    //document.report.reports.value = "";
    for (var i = 0; i < computation.length; i++) {
        var table = document.getElementById("table");
        var row = table.insertRow();
        //var choiceId = computation[i].id;
        var cell1 = row.insertCell(0);
        cell1.innerHTML = computation[i].id;
        var cell2 = row.insertCell(1);
        cell2.innerHTML = computation[i].creationTime;

      
        //var choiceDate = computation[i].date;
        var cell3 = row.insertCell(2);
        cell3.innerHTML = computation[i].completed;

        var cell4 = row.insertCell(3);
        cell4.innerHTML = computation[i].description.slice(0,30);
    
        //var choiceCompleted = computation[i].completed;

    }

    console.log(computation[1].date);
}


function generateReport() {
    //var testChoice = JSON.parse("{\"id\":\"abc-123\",\"description\":\"This is a cool description\",\"alternatives\":[{\"id\":\"alt1\",\"description\":\"Cool Alternative One\",\"approvals\":[{\"author\":{\"tid\":\"tm1\",\"name\":\"Member One\"},\"state\":\"approve\"}],\"feedbacks\":[{\"id\":\"f1\",\"timestamp\":\"2017-06-15 00:00:00\",\"description\":\"I don't like this\",\"author\":{\"tid\":\"tm1\",\"name\":\"Member One\"}}]}],\"members\":[{\"tid\":\"37da5ad5-58aa-4f94-8a2a-a674b6b9cace\",\"name\":\"p2\"},{\"tid\":\"72f2ccb9-9022-44ad-956c-f95502cf6e25\",\"name\":\"CoolGuy123\"},{\"tid\":\"af1aa482-e441-4d83-805d-b375fddcf956\",\"name\":\"p3\"},{\"tid\":\"c2c4ae1c-ef73-4829-b58a-cc4b2b973345\",\"name\":\"Member Two\"},{\"tid\":\"tm1\",\"name\":\"Member One\"}],\"maxMemberCount\":5,\"completed\":false}");
    //var str = JSON.stringify(testChoice, null, " ");
    //document.report.reports.value = str;
    
    var n = document.getElementById("table").children[0].children.length - 1;
    for(var i = 0; i < n; i++){
      document.getElementById("table").children[0].removeChild(document.getElementById("table").children[0].children[1]);
    }
    
    var xhr = new XMLHttpRequest();
    xhr.open("GET", generate_report_url, true);
    xhr.send();

    // This will process results and update HTML as appropriate. 
    xhr.onloadend = function () {
        console.log(xhr);
        console.log(xhr.request);

        if (xhr.readyState == XMLHttpRequest.DONE) {
            console.log("XHR:" + xhr.responseText);
            processGenerateResponse(xhr.responseText);
        } else {
            processGenerateResponse();
        }
    };
}


function deleteOldChoices() {
    var value = document.deleteOld.deletechoices.value;
    var js = JSON.stringify({ days: value });
    var xhr = new XMLHttpRequest();
    xhr.open("POST", remove_choices_url, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(js);

    xhr.onloadend = function () {
        console.log(xhr);
        console.log(xhr.request);

        if (xhr.readyState == XMLHttpRequest.DONE) {
            console.log("XHR:" + xhr.responseText);
            document.deleteOld.delOldRes.value = "Deleted choices after " + document.deleteOld.deletechoices.value + " days";
        }
    }
}