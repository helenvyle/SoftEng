var base_url = "https://38yuo2har2.execute-api.us-east-1.amazonaws.com/beta/"

var create_url = base_url + "choice";
var generate_report_url = base_url + "report/";
var join_url = base_url + "joinChoice/";
var admin_url = base_url + "asdfje321";
var approval_url = base_url +  "approval/";
var remove_choices_url = base_url + "remove/";
var mark_complete_url = base_url + "complete/";
var add_feedback_url = base_url + "feedback/";