function loadChoice(ch) {
    if (ch == null) {
        document.loginForm.result.value = "Failed to join choice."
        return;
    }

    document.title = "Choice";

    window.choice = ch;

    console.log(ch);

    document.loginForm.result.value = "";
    document.getElementById("login").style.display = "none";
    document.getElementById("showChoice").style.display = "block";

    document.getElementById("chid").innerText = "Choice: " + ch.id;
    document.getElementById("chDesc").innerText = ch.description;

    for (var i = 0; i < 5; i++) {
        

        let ii = i;
        document.getElementsByClassName("expand")[i].onclick = function () {
            expandAlternative(ii);
        };

        if (i >= ch.alternatives.length) {
            document.getElementsByClassName("alternative")[i].style.display = "none";
            continue;
        }

        var alt = ch.alternatives[i];
        if (alt == null) {
            document.getElementsByClassName("alternative")[i].style.display = "none";
        }
        if(ch.completed == true && alt.id == ch.chosenAlternative.id){
            document.getElementById(i).style.display = "block";
        }

        var elem = document.getElementsByClassName("alternative")[i];

        elem.getElementsByTagName("h2")[0].innerText = alt.description;

        var nApp = 0;
        var nDisapp = 0;

        alt.approvals.forEach((e) => {
            if (e.state == "approve") nApp++;
            if (e.state == "disapprove") nDisapp++;
        })

        elem.getElementsByClassName("approvals")[0].innerText = elem.getElementsByClassName("approvals")[0].innerText.substring(0, 3) + nApp;
        elem.getElementsByClassName("disapprovals")[0].innerText = elem.getElementsByClassName("disapprovals")[0].innerText.substring(0, 3) + nDisapp;


    }
    if(ch.completed == true){
        document.getElementById("markChosen").disabled = true;
        document.getElementById("addFeedback").style.display = "none";
        document.getElementById("addFeedbackButton").style.display = "none";

    }
    
    if(typeof(hooplah) !== 'undefined'){
        expandAlternative(hooplah);
    }

}

function expandAlternative(index) {
    window.hooplah = index; 
    var alt = window.choice.alternatives[index];
    console.log(alt);

    document.getElementById("altDetails").style.display = "block";

    document.getElementById("selectAlternative").innerText = alt.description;

    // remove selected class from all alternatives
    Array.prototype.slice.call(document.getElementsByClassName("alternative")).forEach(e => e.classList.remove("selected"));

    // add selected class to the desired alternative
    document.getElementsByClassName("alternative")[index].classList.add("selected");

    // fill out detailed approval/disapproval view

    var appsElem = document.getElementById("approvals");
    // remove child elements
    appsElem.innerHTML = "";

    alt.approvals.forEach((a) => {
        var el = document.createElement("div");
        el.classList.add("approvalEntry");
        el.innerText = (a.state == "approve" ? "\uD83D\uDC4D" : "\uD83D\uDC4E") + " \u2013 " + a.author.name;

        appsElem.appendChild(el);
    });

    // fill out feedback view

    var fbElem = document.getElementById("feedbacks");
    // remove child elements
    fbElem.innerHTML = "";

    alt.feedbacks.forEach((f) => {
        var el = document.createElement("div");
        el.classList.add("fbEntry");

        el.innerHTML = "<text style='font-size: 10pt; font-family: monospace'>" + f.timestamp + "</text><br>";
        el.innerHTML += "<b>" + sanitize(f.author.name) + ":</b> " + sanitize(f.description);

        fbElem.appendChild(el);
    });
    
    // sort feedbacks
    
    var fbs = document.getElementById('feedbacks');

    var items = fbs.childNodes;
    var fbarr = [];
    for (var i in items) {
      if (items[i].nodeType == 1) {
        fbarr.push(items[i]);
      }
    }

    // sort alphabetically
    fbarr.sort(function(a, b) {
      return a.innerHTML == b.innerHTML ? 0 : (a.innerHTML > b.innerHTML ? 1 : -1);
    });

    for (i = 0; i < fbarr.length; ++i) {
      fbs.appendChild(fbarr[i]);
    }

}

// prevents very basic injection attacks
function sanitize(str) {
    return str.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function testChoice() {
    var c = JSON.parse("{\"id\":\"abc-123\",\"description\":\"This is a cool description\",\"alternatives\":[{\"id\":\"alt1\",\"description\":\"Cool Alternative One\",\"approvals\":[{\"author\":{\"tid\":\"tm1\",\"name\":\"Member One\"},\"state\":\"approve\"}],\"feedbacks\":[{\"id\":\"f1\",\"timestamp\":\"2017-06-15 00:00:00\",\"description\":\"I don't like this\",\"author\":{\"tid\":\"tm1\",\"name\":\"Member One\"}}]}],\"members\":[{\"tid\":\"37da5ad5-58aa-4f94-8a2a-a674b6b9cace\",\"name\":\"p2\"},{\"tid\":\"72f2ccb9-9022-44ad-956c-f95502cf6e25\",\"name\":\"CoolGuy123\"},{\"tid\":\"af1aa482-e441-4d83-805d-b375fddcf956\",\"name\":\"p3\"},{\"tid\":\"c2c4ae1c-ef73-4829-b58a-cc4b2b973345\",\"name\":\"Member Two\"},{\"tid\":\"tm1\",\"name\":\"Member One\"}],\"maxMemberCount\":5,\"completed\":false}");
    loadChoice(c);
}

function clickJoinChoice() {
    document.loginForm.result.value = "..."
    var cid = document.loginForm.cid.value;
    var name = document.loginForm.name.value;
    var pwd = document.loginForm.pwd.value;

    console.log(cid + " " + name + " " + pwd);

    var data = {};

    //data["cid"] = cid; // path parameter
    data["name"] = name;
    data["password"] = pwd;

    var js = JSON.stringify(data);
    console.log("JS:" + js);
    console.log(join_url + cid);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", join_url + cid, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    // send the collected data as JSON
    xhr.send(js);

    // This will process results and update HTML as appropriate. 
    xhr.onloadend = function () {
        console.log(xhr);
        console.log(xhr.request);

        if (xhr.readyState == XMLHttpRequest.DONE) {
            loadChoice(JSON.parse(xhr.responseText))
            console.log("XHR:" + xhr.responseText);
            //processCreateResponse(arg1, arg2, xhr.responseText);
        } else {
            console.log(xhr.readyState);
            //processCreateResponse(arg1, arg2, "N/A");
        }
    };
}


function processApproval(altIndex, result) {
    console.log(result);
    var js = JSON.parse(result);
    var computation = js; 
    updateApproval(altIndex, computation);
    loadChoice(choice);
    if(typeof(hooplah) !== 'undefined'){
        expandAlternative(hooplah);
    }
}

function setApproval(altIndex, state) {
    var currentState = getCurrentApproval(altIndex);
    var newState = getCurrentApproval(altIndex);
    if(choice.completed == true){
        return; 
    }
    if (state == "approveButton") {
        if (currentState == "none") {
            newState = "approve";
        } else if (currentState == "approve") {
            newState = "none";
        } else if (currentState == "disapprove") {
            newState = "approve";
        }
    }
    else if (state == "disapproveButton") {
        if (currentState == "none") {
            newState = "disapprove";
        } else if (currentState == "approve") {
            newState = "disapprove";
        } else if (currentState == "disapprove") {
            newState = "none";
        }
    }
    console.log("Current State " + currentState);
    console.log("State " + state);
    console.log("New State " + newState);
    var data = {};
    data["author"] = {};
    data["state"] = newState;
    data["author"]["tid"] = choice.members.find(tm => tm.name == document.loginForm.name.value).tid;
    data["author"]["name"] = document.loginForm.name.value;
    data = {judgement: data};
    var js = JSON.stringify(data);
    console.log("JS:" + js);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", approval_url + choice.alternatives[altIndex].id, true);
    console.log(approval_url + choice.alternatives[altIndex].id);

    // send the collected data as JSON
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(js);

    // This will process results and update HTML as appropriate. 
    xhr.onloadend = function () {
        console.log(xhr);
        console.log(xhr.request);

        if (xhr.readyState == XMLHttpRequest.DONE) {
            console.log("XHR:" + xhr.responseText);
            processApproval(altIndex, xhr.responseText);
        } 
    };
}


// given the alternative index (0-4), returns "approve", "disapprove", or "none"
function getCurrentApproval(altIndex) {
    var st = choice.alternatives[altIndex].approvals.find(as => as.author.name == document.loginForm.name.value);
    if (typeof (st) === 'undefined') return "none";
    return st.state;
}


function updateApproval(altIndex, state){
    var app = choice.alternatives[altIndex].approvals.find(ap => ap.author.name == document.loginForm.name.value);
    if(state.state == "none"){
      if(typeof(app) === 'undefined'){
      }else{
        choice.alternatives[altIndex].approvals.splice(choice.alternatives[altIndex].approvals.indexOf(app), 1);
      }
    }else{
      if(typeof(app) === 'undefined'){
        choice.alternatives[altIndex].approvals.push(state);
      }else{
        app.state = state.state;
      }
    }
  }

  function updateFeedback(feedbackContent){
    choice.alternatives[hooplah].feedbacks.push(feedbackContent);
  }
          
  

  function processMarkComplete(result){
      console.log("result: " +  result);
      var js = JSON.parse(result);
      var newChoice = js;
      choice = newChoice;      
      loadChoice(choice);
  }

  function func_markChosen(){
      //var app = choice.alternatives[hooplah].approvals.state
      //var hasApprovals = app.includes("approve");
      //if(hasApprovals){
          var data = choice.alternatives[hooplah].id;
          var xhr = new XMLHttpRequest();
          xhr.open("POST", mark_complete_url + choice.id, true);
          xhr.setRequestHeader("Content-Type", "application/json");
          var js = JSON.stringify({altId: data});
          xhr.send(js);

          xhr.onloadend = function() {
            console.log(xhr);
            console.log(xhr.request);
    
            if (xhr.readyState == XMLHttpRequest.DONE) {
                console.log("XHR:" + xhr.responseText);
                processMarkComplete(xhr.responseText);
            }
        };
      //}
      
  }

  function processSubmit(result){
      console.log(result);
      var js = JSON.parse(result);
      var computation = js; 
      updateFeedback(computation);
      expandAlternative(hooplah);
  }

  function submitFeedback(){
      var feedback = document.getElementById("addFeedback").value;
      var data = {};
      data["name"] = document.loginForm.name.value;
      data["description"] = feedback;
      var js = JSON.stringify(data);

      console.log("JS: " + js);
      var xhr = new XMLHttpRequest();


      xhr.open("POST", add_feedback_url + choice.alternatives[hooplah].id, true);
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.send(js);

      xhr.onloadend = function() {
          console.log(xhr);
          console.log(xhr.request);

          if(xhr.readyState == XMLHttpRequest.DONE){
              console.log("XHR: " + xhr.responseText);
              if(xhr.responseText == "null"){
                clickJoinChoice();
              }else{
                processSubmit(xhr.responseText);
              }
          }
      };
  }






