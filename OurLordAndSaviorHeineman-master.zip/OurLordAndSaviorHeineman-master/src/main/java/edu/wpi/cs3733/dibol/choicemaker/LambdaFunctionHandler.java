package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;

public class LambdaFunctionHandler implements RequestHandler<Object, String> {

    @Override
    public String handleRequest(Object input, Context context) {
    	
        context.getLogger().log("Input: " + input + "\n");
        
        DAO o = new DAO();
		o.putTestEntry();
        
        return "Hello from Lambda!";
    }

}
