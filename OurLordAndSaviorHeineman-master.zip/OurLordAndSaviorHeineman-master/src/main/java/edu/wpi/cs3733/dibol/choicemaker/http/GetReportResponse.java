package edu.wpi.cs3733.dibol.choicemaker.http;

public class GetReportResponse {
	public final String response;
	public final int httpCode;
	
	public GetReportResponse(String s, int code) {
		this.response = s;
		this.httpCode = code;
	}
	
	//success
	public GetReportResponse(String s) {
		this.response = s;
		this.httpCode = 200;
	}
	
	public String toString() {
		return "Response(" + response + ")";
	}
	
}
