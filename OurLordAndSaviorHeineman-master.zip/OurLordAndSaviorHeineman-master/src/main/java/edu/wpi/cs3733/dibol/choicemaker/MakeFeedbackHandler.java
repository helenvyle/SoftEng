package edu.wpi.cs3733.dibol.choicemaker;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeFeedbackRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;
import edu.wpi.cs3733.dibol.choicemaker.model.Feedback;


public class MakeFeedbackHandler implements RequestHandler<MakeFeedbackRequest, Feedback> {

	@Override
	public Feedback handleRequest(MakeFeedbackRequest input, Context context) {
		context.getLogger().log("MakeFeedbackHandler::handleRequest(\"" + input.description + "\")\n");
		Feedback inputFeedback = null;
		DAO o = new DAO();
		
		
		Choice ch = o.getChoice(o.getCidFromAlternative(input.aid));
		if(ch.isCompleted()) return inputFeedback;
		
		try {
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm");
			LocalDateTime currentDate = LocalDateTime.now();
			
			String tid = o.getTidFromName(input.name, input.aid);

			inputFeedback = new Feedback(input.aid, dateFormat.format(currentDate), input.description, tid);
			
			o.makeFeedback(inputFeedback);
			inputFeedback.setAuthor(o.getTeamMember(tid));

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return inputFeedback;
	}
	
}

