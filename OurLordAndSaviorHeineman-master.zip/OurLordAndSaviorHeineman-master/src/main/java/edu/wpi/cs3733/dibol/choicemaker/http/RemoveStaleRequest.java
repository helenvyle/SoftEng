package edu.wpi.cs3733.dibol.choicemaker.http;

public class RemoveStaleRequest {
	public float days;
	
	public RemoveStaleRequest() {}
}
