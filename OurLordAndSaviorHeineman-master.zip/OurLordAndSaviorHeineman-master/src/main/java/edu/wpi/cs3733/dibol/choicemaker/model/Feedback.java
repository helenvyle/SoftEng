package edu.wpi.cs3733.dibol.choicemaker.model;

public class Feedback {
	String aid;
	String timestamp;
	String description;
	String tid;
	String name;
	String fid;
	TeamMember author;

	public Feedback(String aid, String timestamp, String description, String tid) {
		this.aid = aid;
		this.timestamp = timestamp;
		this.description = description;
		this.tid = tid;
	}
	
	public Feedback() {
		
	}
	
	public String getFid() {
		return fid;
	}
	
	public void setFid(String fid) {
		this.fid = fid;
	}

	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}
	
	public TeamMember getAuthor() {
		return author;
	}

	public void setAuthor(TeamMember author) {
		this.author = author;
	}
	
}
