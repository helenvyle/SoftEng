package edu.wpi.cs3733.dibol.choicemaker.http;


public class MakeChoiceRequest {
	public String description;
	public String altdescription1;
	public String altdescription2;
	public String altdescription3;
	public String altdescription4;
	public String altdescription5;
	public int memberCount;
}
