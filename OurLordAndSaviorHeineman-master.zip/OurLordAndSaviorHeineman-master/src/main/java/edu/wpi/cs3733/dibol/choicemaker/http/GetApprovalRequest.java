package edu.wpi.cs3733.dibol.choicemaker.http;

public class GetApprovalRequest {
	public String altId;
	

}
