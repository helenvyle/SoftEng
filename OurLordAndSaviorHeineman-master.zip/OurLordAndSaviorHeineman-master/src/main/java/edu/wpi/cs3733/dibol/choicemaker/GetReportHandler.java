package edu.wpi.cs3733.dibol.choicemaker;

import java.util.ArrayList;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.GetReportRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.GetReportResponse;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class GetReportHandler implements RequestHandler<GetReportRequest, ArrayList<Choice>>{

	LambdaLogger logger;

	@Override
	public ArrayList<Choice> handleRequest(GetReportRequest input, Context context) {
		
		logger = context.getLogger();
		logger.log("GetReportHandler::handleRequest(\"" + input + "\")\n");
		logger.log(input.toString());
		DAO o = new DAO();
		ArrayList<Choice> list = new ArrayList<Choice>();
		GetReportResponse response;

		
		try {
			if(o.GetReport(list)) {
				response = new GetReportResponse("Successfully generated report");
				logger.log(response.toString());
				return list;
			}
		} catch (Exception e){
			response = new GetReportResponse ("Unable to join report");
			logger.log(response.toString());
			
		}
	
		
		return list;
	}

}



