package edu.wpi.cs3733.dibol.choicemaker.http;

public class MakeFeedbackRequest {
	public String description;
	public String name;
	public String aid;
	 
	
	MakeFeedbackRequest() {
		
	}
}
