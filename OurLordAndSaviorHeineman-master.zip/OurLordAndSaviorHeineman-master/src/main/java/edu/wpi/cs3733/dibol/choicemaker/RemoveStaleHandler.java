package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.RemoveStaleRequest;


public class RemoveStaleHandler implements RequestHandler<RemoveStaleRequest, String> {

	@Override
	public String handleRequest(RemoveStaleRequest input, Context context) {
		context.getLogger().log("RemoveStaleHandler::handleRequest(\"" + input.days + "\")\n");
		
		DAO o = new DAO();
		
		o.deleteOlderThan(input.days);
		
		return "Success";
	}
	
}

