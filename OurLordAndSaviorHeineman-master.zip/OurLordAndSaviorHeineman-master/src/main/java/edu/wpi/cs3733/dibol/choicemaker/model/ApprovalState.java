package edu.wpi.cs3733.dibol.choicemaker.model;

public class ApprovalState {
	TeamMember author;
	String state;
	
	public ApprovalState(TeamMember author, String state) {
		this.author = author;
		this.state = state;
	}

	public ApprovalState() {}

	public TeamMember getAuthor() {
		return author;
	}

	public void setAuthor(TeamMember author) {
		this.author = author;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
}
