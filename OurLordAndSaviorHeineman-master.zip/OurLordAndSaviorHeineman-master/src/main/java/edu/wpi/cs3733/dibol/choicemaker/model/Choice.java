package edu.wpi.cs3733.dibol.choicemaker.model;

public class Choice {
	String id;
	String description;
	Alternative[] alternatives;
	TeamMember[] members;
	int maxMemberCount;
	boolean isCompleted;
	String creationTime;
	String completionTime;
	Alternative chosenAlternative;
	
	public Choice(String id, String description, Alternative[] alternatives, int maxMemberCount) {
		this.id = id;
		this.description = description;
		this.alternatives = alternatives;
		this.maxMemberCount = maxMemberCount;
	}
	
	public Choice() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Alternative[] getAlternatives() {
		return alternatives;
	}

	public void setAlternatives(Alternative[] alternatives) {
		this.alternatives = alternatives;
	}

	public TeamMember[] getMembers() {
		return members;
	}

	public void setMembers(TeamMember[] members) {
		this.members = members;
	}

	public int getMaxMemberCount() {
		return maxMemberCount;
	}

	public void setMaxMemberCount(int maxMemberCount) {
		this.maxMemberCount = maxMemberCount;
	}

	public boolean isCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(boolean isCompleted) {
		this.isCompleted = isCompleted;
	}

	public String getCompletionTime() {
		return completionTime;
	}

	public void setCompletionTime(String completionTime) {
		this.completionTime = completionTime;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public Alternative getChosenAlternative() {
		return chosenAlternative;
	}

	public void setChosenAlternative(Alternative chosenAlternative) {
		this.chosenAlternative = chosenAlternative;
	}
	
	
	
}
