package edu.wpi.cs3733.dibol.choicemaker.http;

public class JoinChoiceRequest {
	public String cid;
	public String name;
	public String password;
	
	
	public JoinChoiceRequest() {
		
	}
	public JoinChoiceRequest(String cid) {
		this.cid = cid;
	}
	public JoinChoiceRequest(String cid, String name, String password) {
		this.cid = cid;
		this.name = name;
		this.password = password;
	}
	
	public String getCID() {
		return cid;
	}
	public void setCID(String cid) {
		this.cid = cid;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPass() {
		return password;
	}
	public void setPass(String pass) {
		password = pass;
	}
}
