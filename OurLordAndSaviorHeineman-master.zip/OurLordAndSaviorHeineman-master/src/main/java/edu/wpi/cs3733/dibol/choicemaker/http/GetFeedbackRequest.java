package edu.wpi.cs3733.dibol.choicemaker.http;

public class GetFeedbackRequest {
	public String fid;
}
