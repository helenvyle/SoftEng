package edu.wpi.cs3733.dibol.choicemaker.model;

public class TeamMember {
	String tid;
	String name;
	
	public TeamMember(String tid, String name) {
		this.tid = tid;
		this.name = name;
	}
	
	public TeamMember() {}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
