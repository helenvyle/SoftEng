package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.SetCompletedRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class SetCompletedHandler implements RequestHandler<SetCompletedRequest, Choice>{
	public Choice handleRequest(SetCompletedRequest input, Context context) {
        context.getLogger().log("SetCompletedHandler::handleRequest(\"" + input.id + "\")\n");

        DAO o = new DAO();
        
        Choice ch = o.getChoice(input.id);
		if(ch.isCompleted()) return ch;
        
        return o.setCompleted(input.id, input.altId);
    }
}
