package edu.wpi.cs3733.dibol.choicemaker.model;

public class Alternative {
	String id;
	String description;
	ApprovalState[] approvals;
	Feedback[] feedbacks;
	
	public Alternative(String id, String description, ApprovalState[] approvals, Feedback[] feedbacks) {
		this.id = id;
		this.description = description;
		this.approvals = approvals;
		this.feedbacks = feedbacks;
	}
	
	public Alternative() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ApprovalState[] getApprovals() {
		return approvals;
	}

	public void setApprovals(ApprovalState[] approvals) {
		this.approvals = approvals;
	}

	public Feedback[] getFeedbacks() {
		return feedbacks;
	}

	public void setFeedbacks(Feedback[] feedbacks) {
		this.feedbacks = feedbacks;
	}
	
}
