package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.GetFeedbackRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.GetReportResponse;
import edu.wpi.cs3733.dibol.choicemaker.model.Feedback;

public class GetFeedbackHandler implements RequestHandler<GetFeedbackRequest, Feedback> {
	LambdaLogger logger;
	Feedback feedback = new Feedback();
	GetReportResponse response;
	
	@Override
	public Feedback handleRequest(GetFeedbackRequest input, Context context) {
		logger = context.getLogger();
		logger.log("GetFeedbackHandler::handleRequest(\"" + input.fid);
        logger.log(input.toString());
		DAO o = new DAO();
		
		try {
			feedback = o.getFeedback(input.fid);
		} catch (Exception e) {
			response = new GetReportResponse ("Unable to get feedback");
			logger.log(response.toString());
		}
        return feedback;
	}
}
