package edu.wpi.cs3733.dibol.choicemaker.http;

import edu.wpi.cs3733.dibol.choicemaker.model.ApprovalState;

public class MakeJudgementRequest {
	public String altId;
	public ApprovalState judgement;

}
