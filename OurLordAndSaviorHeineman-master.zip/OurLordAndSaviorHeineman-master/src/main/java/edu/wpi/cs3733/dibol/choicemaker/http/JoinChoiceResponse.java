package edu.wpi.cs3733.dibol.choicemaker.http;

public class JoinChoiceResponse {
	public final String response;
	public final int httpCode;
	
	public JoinChoiceResponse(String s, int code) {
		this.response = s;
		this.httpCode = code;
	}
	
	//success
	public JoinChoiceResponse(String s) {
		this.response = s;
		this.httpCode = 200;
	}
	
	public String toString() {
		return "Response(" + response + ")";
	}
	
	
}

