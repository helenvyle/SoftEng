package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeJudgementRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.ApprovalState;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class MakeJudgementHandler implements RequestHandler<MakeJudgementRequest, ApprovalState>{

	public ApprovalState handleRequest(MakeJudgementRequest input, Context context) {
        context.getLogger().log("MakeJudgementHandler::handleRequest(\"" + input.altId + "\")\n");
        
        DAO o = new DAO();
        
        Choice ch = o.getChoice(o.getCidFromAlternative(input.altId));
		if(ch.isCompleted()) return input.judgement;
        
        String state = input.judgement.getState();
        int judgement = 0;
        if(state.equals("disapprove")) {
        	judgement = 0;
        }
        else if(state.equals("approve")) {
        	judgement = 1;
        }
        else if(state.equals("none")) {
        	judgement = 2;
        }
        else {
        	return null;
        }
        
        return o.MakeJudgement(input.altId, input.judgement.getAuthor().getTid(), judgement);
        
        	
        
    }
}
