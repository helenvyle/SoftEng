package edu.wpi.cs3733.dibol.choicemaker.http;

import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class MakeChoiceResponse {
	public Choice choice;
	public int statusCode;
	public String error;
	
	public MakeChoiceResponse (Choice choice, int statusCode) {
		this.choice = choice;
		this.statusCode = statusCode;
		this.error = "";
	}
	
	public MakeChoiceResponse (int statusCode, String error) {
		this.statusCode = statusCode;
		this.error = "";
	}
}
