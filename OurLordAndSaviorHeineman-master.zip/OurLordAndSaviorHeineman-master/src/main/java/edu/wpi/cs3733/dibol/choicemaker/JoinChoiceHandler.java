package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.JoinChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.JoinChoiceResponse;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class JoinChoiceHandler implements RequestHandler<JoinChoiceRequest, Choice> {
	
	LambdaLogger logger;



	@Override
	public Choice handleRequest(JoinChoiceRequest input, Context context) {
		logger = context.getLogger();
		logger.log("JoinChoiceHandler::handleRequest(\"" + input.cid + "\")\n");
		logger.log(input.toString());
		DAO o = new DAO();

		JoinChoiceResponse response;
		
		try {
			if(o.JoinChoice(input)) {
				response = new JoinChoiceResponse("Successfully joined choice");
				logger.log(response.toString());
				return o.getChoice(input.cid);
			} else {
				return null;
			}
		} catch (Exception e) {
			response = new JoinChoiceResponse("Unable to join choice: " + input.name + "(" + e.getMessage() + ")", 400);
			logger.log(response.toString());
		}
		
		response = new JoinChoiceResponse("You done fricked up", 400);
		logger.log(response.toString());
		
		return null;


	}

		
}



