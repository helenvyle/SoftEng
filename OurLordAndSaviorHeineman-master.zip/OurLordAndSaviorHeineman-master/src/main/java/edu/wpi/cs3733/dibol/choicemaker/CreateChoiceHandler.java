package edu.wpi.cs3733.dibol.choicemaker;

import java.util.UUID;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceResponse;
import edu.wpi.cs3733.dibol.choicemaker.model.Alternative;
import edu.wpi.cs3733.dibol.choicemaker.model.ApprovalState;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;
import edu.wpi.cs3733.dibol.choicemaker.model.Feedback;

public class CreateChoiceHandler implements RequestHandler<MakeChoiceRequest, MakeChoiceResponse>{

	public MakeChoiceResponse handleRequest(MakeChoiceRequest input, Context context) {
		
		boolean fail =  false;
		String message = "";
		Choice madeChoice = null;
		try {
			String uniqueID = UUID.randomUUID().toString();
			ApprovalState[] ApprovalState = null;
			Feedback[] Feedback = null;
			
			Alternative alternative1 = new Alternative(UUID.randomUUID().toString(), input.altdescription1, ApprovalState, Feedback);
			Alternative alternative2 = null;
			Alternative alternative3 = null;
			Alternative alternative4 = null;
			Alternative alternative5 = null;
			if(input.altdescription2 != null) {
				alternative2 = new Alternative(UUID.randomUUID().toString(), input.altdescription2, ApprovalState, Feedback);
			}
			if(input.altdescription3 != null) {
				alternative3 = new Alternative(UUID.randomUUID().toString(), input.altdescription3, ApprovalState, Feedback);
			}
			if(input.altdescription4 != null) {
				alternative4 = new Alternative(UUID.randomUUID().toString(), input.altdescription4, ApprovalState, Feedback);
			}
			if(input.altdescription5 != null) {
				alternative5 = new Alternative(UUID.randomUUID().toString(), input.altdescription5, ApprovalState, Feedback);
			}
			
			Alternative availibleAlternatives[] = {alternative1, alternative2, alternative3, alternative4, alternative5};
			madeChoice = new Choice(uniqueID, input.description, availibleAlternatives, input.memberCount);
			madeChoice.setIsCompleted(false);
			madeChoice.setMaxMemberCount(input.memberCount);
			context.getLogger().log("input for memberCount: " + input.memberCount + " members");
		}
		catch (Exception ex) {
			message = "Can not make this choice.";
			fail = true;
		}
		
		MakeChoiceResponse response;
		if (fail || !inputIntoDatabase(madeChoice)) {
			response = new MakeChoiceResponse(400, message);
		} else {
			response = new MakeChoiceResponse(madeChoice, 200);
		}
		return response;
		
	}
	
	public boolean inputIntoDatabase(Choice choice) {
		DAO o = new DAO();
		boolean succeeded = o.CreateChoice(choice);
		return succeeded;
	}
	
}
