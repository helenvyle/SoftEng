package edu.wpi.cs3733.dibol.choicemaker.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import edu.wpi.cs3733.dibol.choicemaker.http.JoinChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Alternative;
import edu.wpi.cs3733.dibol.choicemaker.model.ApprovalState;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;
import edu.wpi.cs3733.dibol.choicemaker.model.Feedback;
import edu.wpi.cs3733.dibol.choicemaker.model.TeamMember;

public class DAO {

	java.sql.Connection conn;

	final String ALTERNATIVE_TABLE = "Alternative";
	final String CHOICE_TABLE = "Choice";
	final String FEEDBACK_TABLE = "Feedback";
	final String JUDGEMENT_TABLE = "Judgement";
	final String TEAMMEMBER_TABLE = "TeamMember";

	public DAO() {
		try {
			conn = DatabaseUtil.connect();
		} catch (Exception e) {
			conn = null;
			e.printStackTrace();
		}
	}

	public void putTestEntry() {
		try {
			PreparedStatement st = conn.prepareStatement("INSERT INTO Choice (cid, description, date, count) VALUES (\"" + Math.random() + "\", \"3This is a cool description\", DATE(\"2017-06-15\"), 6)");
			st.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Choice getChoice(String id) {

		try {
			PreparedStatement cst = conn.prepareStatement("SELECT * FROM sys.Choice WHERE cid=?");
			cst.setString(1, id);
			ResultSet choice = cst.executeQuery();

			if(choice.next()) {
				Choice c = new Choice();
				c.setId(id);

				c.setDescription(choice.getString("description"));
				c.setMaxMemberCount(choice.getInt("count"));

				// get creation

				String cdate = choice.getString("date");
				if(cdate != null) {
					c.setCreationTime(cdate);
				}else {
					c.setCreationTime("null");	
				}
				
				// get completion

				String date = choice.getString("completionDate");
				if(date != null) {
					c.setIsCompleted(true);
					c.setCompletionTime(date);
					c.setChosenAlternative(getAlternative(choice.getString("chosenAlternative")));
				}else {
					c.setIsCompleted(false);	
				}

				// get team members

				PreparedStatement tst = conn.prepareStatement("SELECT * FROM sys.TeamMember WHERE cid=?");
				tst.setString(1, id);
				ResultSet tms = tst.executeQuery();

				List<TeamMember> mems = new ArrayList<TeamMember>();
				while(tms.next()) {
					mems.add(parseTeamMember(tms));
				}

				c.setMembers(mems.toArray(new TeamMember[] {}));

				// get alternatives

				PreparedStatement altSt = conn.prepareStatement("SELECT * FROM sys.Alternative WHERE cid=?");
				altSt.setString(1, id);
				ResultSet altRes = altSt.executeQuery();

				List<Alternative> alts = new ArrayList<Alternative>();
				while(altRes.next()) {
					alts.add(parseAlternative(altRes));
				}

				c.setAlternatives(alts.toArray(new Alternative[] {}));

				return c;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public Alternative parseAlternative(ResultSet res) throws SQLException {
		Alternative a = new Alternative();

		a.setId(res.getString("aid"));
		a.setDescription(res.getString("description"));

		// get approvals

		PreparedStatement appSt = conn.prepareStatement("SELECT * FROM sys.Judgement WHERE aid=?");
		appSt.setString(1, a.getId());
		ResultSet appRes = appSt.executeQuery();

		List<ApprovalState> approvals = new ArrayList<ApprovalState>();
		while(appRes.next()) {
			approvals.add(parseApprovalState(appRes));
		}

		a.setApprovals(approvals.toArray(new ApprovalState[] {}));

		// get feedbacks

		PreparedStatement feedSt = conn.prepareStatement("SELECT * FROM sys.Feedback WHERE aid=?");
		feedSt.setString(1, a.getId());
		ResultSet feedRes = feedSt.executeQuery();

		List<Feedback> feedbacks = new ArrayList<Feedback>();
		while(feedRes.next()) {
			feedbacks.add(parseFeedback(feedRes));
		}

		a.setFeedbacks(feedbacks.toArray(new Feedback[] {}));

		return a;
	}

	public ApprovalState parseApprovalState(ResultSet res) throws SQLException {
		ApprovalState a = new ApprovalState();

		a.setState(res.getBoolean("status") ? "approve" : "disapprove");

		a.setAuthor(getTeamMember(res.getString("tid")));

		return a;
	}


	public Feedback parseFeedback(ResultSet res) throws SQLException {
		Feedback f = new Feedback();

		f.setFid(res.getString("fid"));
		f.setDescription(res.getString("description"));
		f.setTimestamp(res.getString("timestamp"));
		f.setAuthor(getTeamMember(res.getString("tid")));

		return f;
	}

	public TeamMember parseTeamMember(ResultSet res) throws SQLException {
		TeamMember tm = new TeamMember();

		tm.setTid(res.getString("tid"));
		tm.setName(res.getString("name"));

		return tm;
	}


	public Alternative getAlternative(String id) {
		try {
			PreparedStatement altSt = conn.prepareStatement("SELECT * FROM sys.Alternative WHERE aid=?");
			altSt.setString(1, id);
			ResultSet altRes = altSt.executeQuery();

			if(altRes.next()) {
				return parseAlternative(altRes);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		return null;
	}
	
	public String getCidFromAlternative(String id) {
		try {
			PreparedStatement altSt = conn.prepareStatement("SELECT * FROM sys.Alternative WHERE aid=?");
			altSt.setString(1, id);
			ResultSet altRes = altSt.executeQuery();

			if(altRes.next()) {
				return altRes.getString("cid");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public TeamMember getTeamMember(String id) {
		try {
			PreparedStatement tmSt = conn.prepareStatement("SELECT * FROM sys.TeamMember WHERE tid=?");
			tmSt.setString(1, id);
			ResultSet tmRes = tmSt.executeQuery();

			if(tmRes.next()) {
				return parseTeamMember(tmRes);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		return null;
	}
	
	public String getTidFromName(String name, String aid) {
		String cid = "";
		try {
			PreparedStatement cidSt = conn.prepareStatement("SELECT cid FROM sys.Alternative WHERE aid=?");
			cidSt.setNString(1, aid);
			ResultSet cidRes = cidSt.executeQuery();
			if(cidRes.next()) {
				cid = cidRes.getNString("cid");
			}
			
			PreparedStatement tdSt = conn.prepareStatement("SELECT tid FROM sys.TeamMember WHERE name =? AND cid =?");
			tdSt.setNString(1, name);
			tdSt.setNString(2, cid);
			ResultSet tdRes = tdSt.executeQuery();
			if(tdRes.next()) {
			return tdRes.getString("tid");
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}


	public boolean JoinChoice(JoinChoiceRequest req) {
		try {
			PreparedStatement chSt = conn.prepareStatement("SELECT * FROM sys.Choice WHERE cid=?");
			chSt.setString(1,  req.cid);
			ResultSet chRes = chSt.executeQuery();
			if(chRes!= null) {
				Choice c = getChoice(req.cid);
				PreparedStatement tmSt = conn.prepareStatement("SELECT * FROM sys.TeamMember WHERE cid=?");
				tmSt.setNString(1, req.cid);
				ResultSet tmRes = tmSt.executeQuery();
				//check if teammate already present & if present then check for password
				while (tmRes.next()) {

					TeamMember tm = parseTeamMember(tmRes);

					if(tm!=null && tm.getName().equals(req.name)) {
						PreparedStatement checkSt = conn.prepareStatement("SELECT password FROM sys.TeamMember WHERE tid=?");
						checkSt.setNString(1, tm.getTid());

						ResultSet resPass = checkSt.executeQuery();
						resPass.next();
						if(resPass.getString("password").equals(req.password)) {
							return true;
							//take to admin page
						} else {
							return false;
						}

					}
					chRes.close();
				}


				if(!c.isCompleted() && c.getMembers().length < c.getMaxMemberCount()) {


					chSt = conn.prepareStatement("INSERT INTO " + TEAMMEMBER_TABLE + " (tid, name, password, cid) values(?, ?, ?, ?);");
					chSt.setString(1, UUID.randomUUID().toString());
					chSt.setNString(2, req.name);
					chSt.setNString(3, req.password);
					chSt.setString(4, req.cid);

					chSt.execute();	
					return true;
				}

			}

			return false;

		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean CreateChoice(Choice choice) {
		boolean success = true;
		try {
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime currentDate = LocalDateTime.now();
			PreparedStatement ps1 = conn.prepareStatement("INSERT INTO sys.Choice (cid, description, date, count) VALUES (\"" + choice.getId() + "\", \"" + choice.getDescription() + "\", \"" + dateFormat.format(currentDate) + "\", " + choice.getMaxMemberCount() + ")");
			ps1.execute();
			Alternative alternatives[] = choice.getAlternatives();
			for (int i = 0; i < 5; i++) {
				if (alternatives[i] != null) {
					alternatives[i].setId(UUID.randomUUID().toString());
					PreparedStatement ps2 = conn.prepareStatement("INSERT INTO sys.Alternative (cid, aid, description) VALUES (\"" + choice.getId() + "\", \"" + alternatives[i].getId() + "\", \"" + alternatives[i].getDescription() + "\")");
					ps2.execute();
				}
			}
		}
		catch(SQLException e) {
			success = false;
			e.printStackTrace();
		}
		return success;
	}
	
	public boolean GetReport(ArrayList<Choice> list) throws Exception {
		try {
			PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM sys.Choice;");
			ps1.execute();
			ResultSet rs = ps1.executeQuery();
			
			while(rs.next()) {
				String cid = rs.getString("cid");
				Choice c = getChoice(cid);
				
				list.add(c);
			}	
			
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	public ApprovalState[] GetApprovals(String altId) {
		Alternative alt =  new Alternative();
		try {
			PreparedStatement judgementSt = conn.prepareStatement("SELECT * FROM sys.Judgement WHERE aid=?");
			judgementSt.setString(1, altId);
			ResultSet judgementRes = judgementSt.executeQuery();
	
			List<ApprovalState> approvals = new ArrayList<ApprovalState>();
			while(judgementRes.next()) {
				approvals.add(parseApprovalState(judgementRes));
			}

			alt.setApprovals(approvals.toArray(new ApprovalState[] {}));
			
			return alt.getApprovals();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public ApprovalState MakeJudgement(String altId, String teamMemberId, int judgement) {
		boolean success = true;
		try {
			PreparedStatement checkJudgement = conn.prepareStatement("SELECT count(*) FROM sys.Judgement WHERE aid = ? AND tid = ?");
			checkJudgement.setString(1, altId);
			checkJudgement.setString(2, teamMemberId);
			ResultSet checkJudgementRes = checkJudgement.executeQuery();
			checkJudgementRes.next();
			int numJudgement = checkJudgementRes.getInt("count(*)");
			PreparedStatement checkJudgementAfterCheck = conn.prepareStatement("SELECT * FROM sys.Judgement WHERE aid = ? AND tid = ?");
			checkJudgementAfterCheck.setString(1, altId);
			checkJudgementAfterCheck.setString(2, teamMemberId);
			ResultSet checkJudgementAfterCheckRes = checkJudgementAfterCheck.executeQuery();
			checkJudgementAfterCheckRes.next();
			if (numJudgement == 1) {
				if(judgement == 2) {
					PreparedStatement deleteJudgement = conn.prepareStatement("DELETE FROM sys.Judgement WHERE aid = ? AND tid = ?");
					deleteJudgement.setString(1, altId);
					deleteJudgement.setString(2, teamMemberId);
					deleteJudgement.execute();
					ApprovalState updatedApprovalState = new ApprovalState(getTeamMember(teamMemberId), "none");
					return updatedApprovalState;
				}
				else {
					String jid = checkJudgementAfterCheckRes.getString("jid");
					PreparedStatement changeJudgement = conn.prepareStatement("UPDATE sys.Judgement SET status = ? WHERE jid = ?");
					changeJudgement.setInt(1, judgement);
					changeJudgement.setString(2, jid);
					changeJudgement.execute();
				}
			}
			else if (numJudgement == 0) {
				String jid = UUID.randomUUID().toString();
				PreparedStatement makeNewStatement = conn.prepareStatement("INSERT INTO sys.Judgement (jid, tid, aid, status) VALUES (\"" + jid + "\", \"" + teamMemberId + "\", \"" + altId + "\", \"" + judgement + "\")");
				makeNewStatement.execute();
			}
			else {
				success = false;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
			success = false;
		}
		
		if(success) {
			if(judgement == 0) {
				ApprovalState updatedApprovalState = new ApprovalState(getTeamMember(teamMemberId), "disapprove");
				return updatedApprovalState;
			}
			else {
				ApprovalState updatedApprovalState = new ApprovalState(getTeamMember(teamMemberId), "approve");
				return updatedApprovalState;
			}
		}
		else {
			return null;
		}
	}

	public Choice setCompleted(String cid, String altId) {
		Choice completedState = null;
		boolean success = true;
		try {
			PreparedStatement check = conn.prepareStatement("SELECT * FROM sys.Choice WHERE cid = ?");
			check.setString(1, cid);
			ResultSet checkRes = check.executeQuery();
			checkRes.next();
			String chosen = checkRes.getString("chosenAlternative");
			if(chosen == null) {
				DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
				LocalDateTime currentDate = LocalDateTime.now();
				PreparedStatement ps1 = conn.prepareStatement("UPDATE sys.Choice SET completionDate = ? WHERE cid = ?");
				ps1.setString(1, dateFormat.format(currentDate));
				ps1.setString(2, cid);
				ps1.execute();
				
				PreparedStatement ps2 = conn.prepareStatement("UPDATE sys.Choice SET chosenAlternative = ? WHERE cid = ?");
				ps2.setString(1, altId);
				ps2.setString(2, cid);
				ps2.execute();
				
				completedState = getChoice(cid);
			}
			else {
				return null;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			success = false;
		}
		if(success) {
			return completedState;
		}
		else {
			return null;
		}
	}
	
	//fid, tid, description, aid
	public boolean makeFeedback(Feedback feedback) {
		boolean success = false;
		try {
			//can one person make multiple feedbacks?
			PreparedStatement fbSt = conn.prepareStatement("INSERT INTO sys.Feedback (fid, tid, description, timestamp, aid) values (?, ?, ?, ?, ?);");
			fbSt.setString(1, UUID.randomUUID().toString());
			fbSt.setNString(2, feedback.getTid());
			fbSt.setNString(3, feedback.getDescription());
			fbSt.setString(4, feedback.getTimestamp());
			fbSt.setNString(5, feedback.getAid());
			fbSt.execute();
			success = true;
		}
		
		catch(SQLException e) {
			e.printStackTrace();
			success = false;
		}
		
		return success;
	}

	public Feedback getFeedback(String fid) {
		try { 
			PreparedStatement fbSt = conn.prepareStatement("SELECT * FROM sys.Feedback WHERE fid =?");
			fbSt.setNString(1, fid);
			ResultSet fbRes = fbSt.executeQuery();
			if(fbRes.next()) {
				return parseFeedback(fbRes);
			}
	
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		
		
		return null;
	}

	public void deleteOlderThan(float days) {
		try {
			PreparedStatement chSt = conn.prepareStatement("SELECT * FROM sys.Choice where TIMESTAMPDIFF(SECOND, date, ?) > 24*60*60*?");
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime currentDate = LocalDateTime.now();
			chSt.setString(1, dateFormat.format(currentDate));
			chSt.setFloat(2, days);
			
			ResultSet rs = chSt.executeQuery();
			
			while(rs.next()) {
				String cid = rs.getString("cid");
				deleteChoice(cid);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteChoice(String cid) {
		System.out.println("Deleting choice: " + cid);
		try {
			PreparedStatement tmSt = conn.prepareStatement("DELETE FROM sys.TeamMember where cid=?");
			tmSt.setString(1, cid);
			tmSt.execute();
			
			PreparedStatement alSt = conn.prepareStatement("SELECT * FROM sys.Alternative where cid=?");
			alSt.setString(1, cid);
			
			ResultSet rs = alSt.executeQuery();
			while(rs.next()) {
				String altId = rs.getString("aid");
				deleteAlternative(altId);
			}
			
			PreparedStatement chSt = conn.prepareStatement("DELETE FROM sys.Choice where cid=?");
			chSt.setString(1, cid);
			chSt.execute();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteAlternative(String aid) {
		System.out.println("Deleting alternative: " + aid);
		try {
			PreparedStatement appSt = conn.prepareStatement("DELETE FROM sys.Judgement where aid=?");
			appSt.setString(1, aid);
			appSt.execute();
			
			PreparedStatement fbSt = conn.prepareStatement("DELETE FROM sys.Feedback where aid=?");
			fbSt.setString(1, aid);
			fbSt.execute();
			
			PreparedStatement altSt = conn.prepareStatement("DELETE FROM sys.Alternative where aid=?");
			altSt.setString(1, aid);
			altSt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
}
