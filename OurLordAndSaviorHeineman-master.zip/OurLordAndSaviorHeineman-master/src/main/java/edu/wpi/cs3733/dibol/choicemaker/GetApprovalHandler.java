package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.GetApprovalRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.ApprovalState;

public class GetApprovalHandler implements RequestHandler<GetApprovalRequest, ApprovalState[]>{

	public ApprovalState[] handleRequest(GetApprovalRequest input, Context context) {
        context.getLogger().log("GetApprovalHandler::handleRequest(\"" + input.altId + "\")\n");
        
        DAO o = new DAO();
        return o.GetApprovals(input.altId);
    }
	
}
