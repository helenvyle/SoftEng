package edu.wpi.cs3733.dibol.choicemaker.http;

import java.util.ArrayList;

import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class GetReportRequest {
	public Choice c; 
	public ArrayList<Choice> list;
	
	public GetReportRequest() {
		
	}
}
