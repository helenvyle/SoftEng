package edu.wpi.cs3733.dibol.choicemaker;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.GetChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class GetChoiceHandler implements RequestHandler<GetChoiceRequest, Choice> {

    @Override
    public Choice handleRequest(GetChoiceRequest input, Context context) {
        context.getLogger().log("GetChoiceHandler::handleRequest(\"" + input.id + "\")\n");
        
        DAO o = new DAO();
        return o.getChoice(input.id);
    }

}
