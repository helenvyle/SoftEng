package edu.wpi.cs3733.dibol.choicemaker.http;

public class SetCompletedRequest {
	public String id;
	public String altId;
}
