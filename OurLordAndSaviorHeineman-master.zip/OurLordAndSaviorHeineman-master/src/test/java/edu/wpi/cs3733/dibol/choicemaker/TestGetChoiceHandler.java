
package edu.wpi.cs3733.dibol.choicemaker;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import edu.wpi.cs3733.dibol.choicemaker.http.GetChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class TestGetChoiceHandler {

	@Test
	public void testGetChoice() {
		GetChoiceHandler ch = new GetChoiceHandler();
		GetChoiceRequest rq = new GetChoiceRequest();
		rq.id = "abc-123";
		Choice c = ch.handleRequest(rq, new TestContext());
		
		assertEquals(c.getId(), "abc-123");
		assertEquals(c.getDescription(), "Test Choice - DO NOT DELETE");
		assertEquals(c.getAlternatives().length, 2);
		
		assertEquals(c.getAlternatives()[0].getId(), "alt1");
		assertEquals(c.getAlternatives()[0].getDescription(), "Cool Alternative One");
		
		assertEquals(c.getAlternatives()[1].getId(), "alt2");
		assertEquals(c.getAlternatives()[1].getDescription(), "This is a second alternative");
		
		assertEquals(c.getMaxMemberCount(), 500);
		assertEquals(c.isCompleted(), false);
		assertEquals(c.getCreationTime(), "2030-12-02 23:13:00");
		assertEquals(c.getChosenAlternative(), null);
		assertEquals(c.getCompletionTime(), null);
		
	}

}

