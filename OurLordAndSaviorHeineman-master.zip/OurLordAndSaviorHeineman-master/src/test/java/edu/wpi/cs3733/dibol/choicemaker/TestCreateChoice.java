package edu.wpi.cs3733.dibol.choicemaker;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceResponse;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class TestCreateChoice {

	@Test
	public void test() {
		DAO dao = new DAO();
		
		CreateChoiceHandler handler = new CreateChoiceHandler();
		MakeChoiceRequest rq = new MakeChoiceRequest();
		rq.description = "This is a test description from TestCreateChoice";
		rq.altdescription1 = "Alternative 1 description from TestCreateChoice";
		rq.altdescription2 = "Alternative 2 description from TestCreateChoice";
		rq.altdescription3 = "Alternative 3 description from TestCreateChoice";
		rq.altdescription4 = "Alternative 4 description from TestCreateChoice";
		rq.altdescription5 = "Alternative 5 description from TestCreateChoice";
		rq.memberCount = 4;
		
		MakeChoiceResponse resp = handler.handleRequest(rq, new TestContext());
		assertEquals(rq.description, resp.choice.getDescription());
		assertEquals(rq.altdescription1, resp.choice.getAlternatives()[0].getDescription());
		assertEquals(rq.altdescription2, resp.choice.getAlternatives()[1].getDescription());
		assertEquals(rq.altdescription3, resp.choice.getAlternatives()[2].getDescription());
		assertEquals(rq.altdescription4, resp.choice.getAlternatives()[3].getDescription());
		assertEquals(rq.altdescription5, resp.choice.getAlternatives()[4].getDescription());
		assertEquals(rq.memberCount, resp.choice.getMaxMemberCount());
		assertNull(resp.choice.getMembers());
		assertFalse(resp.choice.isCompleted());
		
		Choice ch = dao.getChoice(resp.choice.getId());
		assertEquals(rq.description, ch.getDescription());
		System.out.println(ch.getAlternatives()[0].getDescription());
		assertEquals(5, ch.getAlternatives().length);
		assertEquals(rq.memberCount, ch.getMaxMemberCount());
		assertEquals(0, ch.getMembers().length);
		assertFalse(ch.isCompleted());
	
		dao.deleteChoice(resp.choice.getId());
		
		assertNull(dao.getChoice(resp.choice.getId()));
		
	}

}
