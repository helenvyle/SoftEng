
package edu.wpi.cs3733.dibol.choicemaker;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Test;

import edu.wpi.cs3733.dibol.choicemaker.http.GetReportRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class TestGetReportHandler {

	@Test
	public void testGetReport() {
		GetReportHandler ch = new GetReportHandler();
		GetReportRequest rq = new GetReportRequest();
		ArrayList<Choice> c = ch.handleRequest(rq, new TestContext());
		
		assertTrue(c.size() > 0);
		
	}

}

