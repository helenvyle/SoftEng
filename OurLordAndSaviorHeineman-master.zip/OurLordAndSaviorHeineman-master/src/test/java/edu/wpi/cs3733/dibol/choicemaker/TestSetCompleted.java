package edu.wpi.cs3733.dibol.choicemaker;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceResponse;
import edu.wpi.cs3733.dibol.choicemaker.http.SetCompletedRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Alternative;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;

public class TestSetCompleted {

	@Test
	public void test() {
		DAO dao = new DAO();
		
		CreateChoiceHandler handler = new CreateChoiceHandler();
		MakeChoiceRequest rq = new MakeChoiceRequest();
		rq.description = "This is a test description from TestSetCompleted";
		rq.altdescription1 = "Alternative 1 description from TestSetCompleted";
		rq.altdescription2 = "Alternative 2 description from TestSetCompleted";
		rq.altdescription3 = "Alternative 3 description from TestSetCompleted";
		rq.altdescription4 = "Alternative 4 description from TestSetCompleted";
		rq.altdescription5 = "Alternative 5 description from TestSetCompleted";
		rq.memberCount = 4;
		
		MakeChoiceResponse resp = handler.handleRequest(rq, new TestContext());
		
		Choice ch = dao.getChoice(resp.choice.getId());
		assertEquals(rq.memberCount, ch.getMaxMemberCount());
		assertEquals(0, ch.getMembers().length);
		assertFalse(ch.isCompleted());
		
		Alternative selection = ch.getAlternatives()[0];
	
		SetCompletedHandler chandler = new SetCompletedHandler();
		SetCompletedRequest crq = new SetCompletedRequest();
		crq.id = ch.getId();
		crq.altId = selection.getId();
		
		Choice cresp = chandler.handleRequest(crq, new TestContext());
		assertEquals(ch.getId(), cresp.getId());
		assertTrue(cresp.isCompleted());
		assertEquals(selection.getId(), cresp.getChosenAlternative().getId());
		
		dao.deleteChoice(resp.choice.getId());
		
		assertNull(dao.getChoice(resp.choice.getId()));
		
	}

}
