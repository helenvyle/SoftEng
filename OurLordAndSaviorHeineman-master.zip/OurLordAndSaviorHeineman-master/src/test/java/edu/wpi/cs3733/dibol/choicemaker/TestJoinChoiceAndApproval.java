package edu.wpi.cs3733.dibol.choicemaker;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import edu.wpi.cs3733.dibol.choicemaker.db.DAO;
import edu.wpi.cs3733.dibol.choicemaker.http.JoinChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceRequest;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeChoiceResponse;
import edu.wpi.cs3733.dibol.choicemaker.http.MakeJudgementRequest;
import edu.wpi.cs3733.dibol.choicemaker.model.Alternative;
import edu.wpi.cs3733.dibol.choicemaker.model.ApprovalState;
import edu.wpi.cs3733.dibol.choicemaker.model.Choice;
import edu.wpi.cs3733.dibol.choicemaker.model.TeamMember;

public class TestJoinChoiceAndApproval {

	@Test
	public void test() {
		DAO dao = new DAO();
		
		CreateChoiceHandler handler = new CreateChoiceHandler();
		MakeChoiceRequest rq = new MakeChoiceRequest();
		rq.description = "This is a test description from TestJoinChoiceAndApproval";
		rq.altdescription1 = "Alternative 1 description from TestJoinChoiceAndApproval";
		rq.altdescription2 = "Alternative 2 description from TestJoinChoiceAndApproval";
		rq.altdescription3 = "Alternative 3 description from TestJoinChoiceAndApproval";
		rq.altdescription4 = "Alternative 4 description from TestJoinChoiceAndApproval";
		rq.altdescription5 = "Alternative 5 description from TestJoinChoiceAndApproval";
		rq.memberCount = 4;
		
		MakeChoiceResponse resp = handler.handleRequest(rq, new TestContext());
		
		Choice ch = dao.getChoice(resp.choice.getId());
		assertEquals(rq.memberCount, ch.getMaxMemberCount());
		assertEquals(0, ch.getMembers().length);
		assertFalse(ch.isCompleted());
	
		// join the choice
		
		JoinChoiceHandler jhandler = new JoinChoiceHandler();
		JoinChoiceRequest jrq = new JoinChoiceRequest();
		jrq.cid = resp.choice.getId();
		jrq.name = "TestJoinChoice Member";
		
		Choice jresp = jhandler.handleRequest(jrq, new TestContext());
		assertEquals(jrq.cid, jresp.getId());
		assertEquals(1, jresp.getMembers().length);
		assertEquals(jrq.name, jresp.getMembers()[0].getName());
		
		// add approval
		Alternative alt = jresp.getAlternatives()[0];
		assertEquals(0, alt.getApprovals().length);
		
		TeamMember tm = dao.getTeamMember(jresp.getMembers()[0].getTid());
		assertEquals(jrq.name, tm.getName());
		
		MakeJudgementHandler judge = new MakeJudgementHandler();
		
		// request 1
		MakeJudgementRequest judgeRq1 = new MakeJudgementRequest();
		judgeRq1.altId = alt.getId();
		judgeRq1.judgement = new ApprovalState();
		judgeRq1.judgement.setAuthor(tm);
		judgeRq1.judgement.setState("approve");
		judge.handleRequest(judgeRq1, new TestContext());
		
		Choice judge1Ch = dao.getChoice(resp.choice.getId());
		assertEquals(1, judge1Ch.getAlternatives()[0].getApprovals().length);
		ApprovalState st1 = judge1Ch.getAlternatives()[0].getApprovals()[0];
		assertEquals(judgeRq1.judgement.getAuthor().getTid(), st1.getAuthor().getTid());
		assertEquals(judgeRq1.judgement.getState(), st1.getState());
		
		// request 2
		MakeJudgementRequest judgeRq2 = new MakeJudgementRequest();
		judgeRq2.altId = alt.getId();
		judgeRq2.judgement = new ApprovalState();
		judgeRq2.judgement.setAuthor(tm);
		judgeRq2.judgement.setState("disapprove");
		judge.handleRequest(judgeRq2, new TestContext());
		
		Choice judge2Ch = dao.getChoice(resp.choice.getId());
		assertEquals(1, judge2Ch.getAlternatives()[0].getApprovals().length);
		ApprovalState st2 = judge2Ch.getAlternatives()[0].getApprovals()[0];
		assertEquals(judgeRq2.judgement.getAuthor().getTid(), st2.getAuthor().getTid());
		assertEquals(judgeRq2.judgement.getState(), st2.getState());

		// request 3
		MakeJudgementRequest judgeRq3 = new MakeJudgementRequest();
		judgeRq3.altId = alt.getId();
		judgeRq3.judgement = new ApprovalState();
		judgeRq3.judgement.setAuthor(tm);
		judgeRq3.judgement.setState("none");
		judge.handleRequest(judgeRq3, new TestContext());
		
		Choice judge3Ch = dao.getChoice(resp.choice.getId());
		assertEquals(0, judge3Ch.getAlternatives()[0].getApprovals().length);
		
		// cleanup
		dao.deleteChoice(resp.choice.getId());
		
		assertNull(dao.getChoice(resp.choice.getId()));
		
	}

}
